# 👑 𝐃𝟑𝟑𝐏 𝐁𝟒𝐃𝐌𝟒𝐒𝐇 𝐅𝐈𝐆𝐇𝐓 𝐁𝐎𝐓 👑

### ` ⚠️  𝐒𝟒𝐁 𝐇𝟒𝐓𝟑𝐑𝐒 𝐊𝐈 𝐌𝟒𝟒 𝐂𝐇𝐎𝐃𝐍𝟑 𝐖𝟒𝐋𝟒 𝐅𝐓 𝐃𝟑𝟑𝐏 𝐁𝟒𝐃𝐌𝟒𝐒𝐇 ! ⚠️ `

![D33P XD INXIDE](https://i.ibb.co/1YkGn1ts/34b55d0c232d6b7ba78dde006e979dfc.jpg)

---

## 😈 𝗕𝗮𝗮𝗽 𝗞𝗮 𝗜𝗻𝘁𝗿𝗼𝗱𝘂𝗰𝘁𝗶𝗼𝗻:

### `👑 𝐃𝟑𝟑𝐏 𝐁𝟒𝐃𝐌𝟒𝐒𝐇 𝐇𝟑𝐑𝟑 👑`
`📲 CONTACT: +91 7719437293 `

---

## 🔥 𝙳𝟹𝟹𝙿 𝙱𝟺𝙳𝙼𝟺𝚂𝙷 𝙱𝙾𝚃 𝙺𝚈𝟺 𝙺𝟺𝚁 𝚂𝟺𝙺𝚃𝟺 𝙷𝟺𝙸 ?

Yeh bot sirf ek tool nahi, yeh **tufaan** hai! Jiske commands se aap apne group ko **pura control** kar sakte hain aur har hater ko uski **aukaat dikha sakte hain!**

### 🛡️ **Group Security - Haters Ki Gaand Tod Dega!**
* **Group Name Lock:** Koi mai ka laal group ka naam nahi badal payega!
* **Nickname Lock:** Members ka nickname lock, takkar lega toh nanga kar dega!
* **Photo Lock:** Group ki DP change karne ki sochna bhi mat!
* **Bot Nickname Set:** Bot ka khud ka fadu nickname set kare, jo koi nahi badal payega!

### 🎯 **Target System - Haters ki Maa Chod De!**
* Kisi bhi hater ko `target` kare aur uski life haram kar de messages se.
* Automatic messages, nonstop, seedha dimaag kharab!

### ⚔️ **Fight Mode - Maaro Madarjaat Ko!**
* `Fight` mode on karein aur dekhe kaise bot haters ki band bajata hai.
* Gaaliyon ka toofan, koi nahi bach payega!

### 🚀 **Aur Bhi Bahut Kuch - Sochna Bhi Mat Challenge Karne Ki!**
* **Admin Commands:** Sirf aapke liye, poora control!
* **Smart Responses:** Bot ka jawab sunke hater khud moot denge!
* **Auto Nickname Correction:** Bot apna nickname kabhi galat nahi hone dega!

---

## ⚙️ 𝗞𝗮𝗶𝘀𝗲 𝗜𝘀𝘁𝗲𝗺𝗮𝗹 𝗞𝗮𝗿𝗲𝗶𝗻?

1.  **Code Ko Download Karein:** Is poore repository ko apne machine pe clone ya download kar lein.
2.  **Dependencies Install Karein:** `npm install` chala ke saare modules install karein.
3.  **`config.json` Setup Karein:**
    * Sirf `botNickname` yahan set karein:
        ```json
        {
          "botNickname": "👑 𝐃𝟑𝟑𝐏 𝐁𝟒𝐃𝐌𝟒𝐒𝐇 𝐁𝐎𝐓 👑"
        }
        ```
4.  **Bot Ko Run Karein:** `node index.js` ya `npm start` se bot ko chala dein.
5.  **Dashboard Se Configure Karein:** Bot ka web dashboard (`http://localhost:3000`) open karein aur wahan se apne Facebook cookies aur Admin ID daal kar bot ko activate karein.

---

## ⚠️ 𝗪𝗔𝗥𝗡𝗜𝗡𝗚 ⚠️

**Yeh bot sirf shaktishali logon ke liye bana hai. Agar aap kamzor dil ke hain toh door rahein!**
**Haters ko koi maaf nahi!**

---

Made with 🤍 by **𝐃𝟑𝟑𝐏 𝐁𝟒𝐃𝐌𝟒𝐒𝐇**
